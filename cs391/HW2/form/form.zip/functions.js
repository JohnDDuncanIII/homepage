/** This is the only file you will need to edit. */

var color = document.getElementById("color");
var colorHex = document.getElementById("colorHex"); 
var button = document.getElementById("submit");
var h1 = document.getElementById("hex1");
var h2 = document.getElementById("hex2");
var h3 = document.getElementById("hex3");
var pageRoot = document.documentElement;

/**
   In this function, concatenate all of the values together from the three hex inputs 
      and then set the values of the color and colorHex inputs to the fullHex string. 
      Basically, turn aa ff 00 (from the three different
      input fields, respectively) into a string (fullHex) containing something like: "#aaff00"
   Then, with the full hex string, set the background of the pageRoot to the fullHex
      color. hint: you will need to use pageRoot.style to do this.
   This function should be around ~5 lines
*/
function setColorPicker() {
    var fullHex = '#';
}

button.onclick = setColorPicker;

/**
   In this function, you will be using the value returned from the color input
      to set the page background (as you did above; 
      hint: use .value to get the color from the color input, 
      then set the pageRoot as you did above using .style). 
   You will also need to set the value of the colorHex text input to this returned value
      and then use substring to get each hex val (i.e., 00) from the returned string 
      (#ffaa00, for example) to set the values of the three input fields to contain 
      each hex value of the entire string.
   This function should have around ~7 lines
*/
function setHexFields() {

}

color.onchange = setHexFields;
